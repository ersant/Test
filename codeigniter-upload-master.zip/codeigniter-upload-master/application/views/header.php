<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<title>Codeigniter 3 - Form &amp; File upload tutorial</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?=base_url();?>assets/css/bootstrap.min.css" />
</head>
<body>
<div class="container">

  <h1 style="font-style:italic">Codeigniter 3 - Form &amp; File upload tutorial</h1>
	<hr />